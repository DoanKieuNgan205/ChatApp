# Binary Caching

The documentation for this topic has been moved to the following articles in [Microsoft Learn](https://learn.microsoft.com/vcpkg):

* [Binary caching](https://learn.microsoft.com/vcpkg/users/binarycaching)
